# Image-Recognition-System
Develop an image classification model to identify objects in images
